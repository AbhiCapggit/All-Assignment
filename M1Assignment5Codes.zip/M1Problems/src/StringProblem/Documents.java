package StringProblem;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Documents {
	String pancard; // BJQPB6259N
	String passportNumber;// K113334B

	public Documents(String pancard, String passportNumber) {

		if(this.verifyPancard(pancard) && this.verifyPassport(passportNumber))
		{
			this.pancard = pancard;
			this.passportNumber = passportNumber;
		} else {
			this.pancard = null;
			this.passportNumber = null;
		}

	}

	public boolean verifyPancard(String pancard)
	{
		boolean isVerified = false;
		Pattern p = Pattern.compile("^[a-zA-Z]{5}[0-9]{4}[a-zA-z]{1}$");
		Matcher m = p.matcher(pancard);
		if (m.matches()) {
			isVerified = true;
		}
		return isVerified;
	}

	public boolean verifyPassport(String passwport)
	{
		boolean isVerified = false;
		Pattern p = Pattern.compile("^[ABCDKabcdk]{1}[0-9]{6}[a-zA-Z]{1}$");
		Matcher m = p.matcher(passwport);
		if (m.matches()) {
			isVerified = true;
		}
		return isVerified;
	}

}

class StringPracticeTest {
	public static void main(String[] args) {
		Documents doc1 = new Documents("BJQPB6259N", "K113334B");
        Documents doc2 = new Documents("AAAA123", "123456A");

        System.out.println("PAN Card 1: " + doc1.pancard);
        System.out.println("Passport 1: " + doc1.passportNumber);

 

        System.out.println("PAN Card 2: " + doc2.pancard);
        System.out.println("Passport 2: " + doc2.passportNumber);

        System.out.println(doc1.verifyPancard("BJQPB6259N"));
        System.out.println(doc1.verifyPassport("K113334B"));

        System.out.println(doc1.verifyPancard("AAAA123"));
        System.out.println(doc1.verifyPassport("123456A"));

	}
}
	
	