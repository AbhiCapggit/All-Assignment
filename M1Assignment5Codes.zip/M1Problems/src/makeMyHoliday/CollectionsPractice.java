package makeMyHoliday;

import java.util.List;
import java.util.Map;


public class CollectionsPractice {
	
	public static void main(String[] args) {
		HotelService hs = new HotelService();
		hs.allHotels.add(new Hotels("LemonTree","Bangalore",4.3f));
		hs.allHotels.add(new Hotels("Sarovar Premiere","Solapur",4.8f));

		Map<String, List<Hotels>>ans=hs.getHotelsByCityName("Bengluru");

		

	 List<Hotels> pop =hs.getHotelsBasedOnCityNameAndRating("Bangalore",4.3f);
	 System.out.println(pop.get(0));

	}

}


