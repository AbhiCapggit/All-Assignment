package makeMyHoliday;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class HotelService {
	
List<Hotels> allHotels=new ArrayList<>();
	
	public boolean insertHotel(Hotels hotel) {
		if(!(allHotels.contains(hotel))) {
			allHotels.add(hotel);
			return true;
		}
		return false;
	}
	
	public Map<String,List<Hotels>> getHotelsByCityName(String cityName){
		Map<String,List<Hotels>> map=new HashMap<>();
		List<Hotels> templist=new ArrayList<>();
		for(Hotels hotel: allHotels) {
			if(hotel.cityname.equals(cityName)) {
				templist.add(hotel);
				map.put(cityName, templist);
			}
		}	
		return map;
	}
	
	public List<Hotels> getHotelsBasedOnCityNameAndRating(String cityName,float rating){
		List<Hotels> templist=new ArrayList<>();
		for(Hotels hotel:allHotels) {
			if(hotel.cityname.equals(cityName) && hotel.userRatings==rating) {
				templist.add(hotel);
			}
		}
		return templist;
	}

}


